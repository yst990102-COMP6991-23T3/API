#!/usr/bin/env bash
/usr/local/bin/6991 cargo test
