#!/usr/bin/env python3
# this example outputsa basic tests.txt
# which has one test - that has no stdin

from cs6991 import test

test.init(__file__)

test.case("", args=["42", "123.456", "F"])
test.case("", args=["1", "17.45", "Z"])
test.case("", args=["101", "99999.999", "q"])
test.case("", args=["77", "777.777", "X"])
test.case("", args=["127", "1.27", "&"])
