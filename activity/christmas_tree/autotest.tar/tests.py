#!/usr/bin/env python3

from cs6991 import test

test.init(__file__)

test.case("[]")

test.case("[Reset]")

test.case("[Left, Right, Reset, Right, Left]")

test.case("[Set(0), Left, Set(20), Right, Set(40), Reset, Set(100), Right, Set(80), Left, Set(60)]")

test.case("[Set(50), Left, Set(100), Left, Set(100), Left, Set(100), Reset, Set(0), Right, Set(0), Set(0)]")
