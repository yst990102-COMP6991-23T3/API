#!/usr/bin/env bash

# untar
tar -xvf crate.tar >/dev/null 2>&1

/usr/local/bin/6991 cargo test
