#!/usr/bin/env python3

from cs6991 import test

test.init(__file__)

test.case("")
