#!/bin/bash

# [ ! -e mark_request.txt ] && echo "You must include a mark_request.txt" && exit 1

cd mark_wrapper
/usr/local/bin/6991 cargo build --target-dir ./target/
