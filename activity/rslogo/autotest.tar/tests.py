#!/usr/bin/env python3
# this example outputs a basic tests.txt
# which has one test - that has no stdin

from cs6991 import test
from pathlib import Path

test.init(__file__, compile_commands=[
    './build_mark_wrapper.sh'
], header = "max_stdout_bytes=50000")

# def case(stdin, args = None, command = None, autotest_command = None, shell = False):
for testcase in sorted(Path('logo_examples').glob('*')):
    expectation = 'EXPECT_ERROR' if 'err' in testcase.stem else 'EXPECT_OK'
    cmd = ['mark_wrapper/target/debug/mark_wrapper', expectation, './target/debug/rslogo', 'output.svg', str(testcase), 'output.svg', '200', '200']
    test.case(stdin='', command=cmd, autotest_command=cmd)
