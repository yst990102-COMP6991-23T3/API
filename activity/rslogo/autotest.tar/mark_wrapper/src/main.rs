use std::env;
use std::process::Command;
use std::fs;
use std::io::{self, Write};
use std::path::Path;

fn main() {
    let args: Vec<String> = env::args().collect();

    if args.len() < 5 {
        eprintln!("Usage: {} <EXPECT_OK|EXPECT_ERROR> <program_path> <output_file> <program_args...>", &args[0]);
        std::process::exit(1);
    }

    let expect_ok = args[1] == "EXPECT_OK";
    let program_path = &args[2];
    let output_file = &args[3];
    let program_args: Vec<&str> = args[4..].iter().map(|s| s.as_str()).collect();

    let mut command = Command::new(program_path);
    command.args(&program_args);

    let output = match command.output() {
        Ok(output) => output,
        Err(e) => {
            eprintln!("Error running the program: {}", e);
            std::process::exit(1);
        }
    };

    if expect_ok {
        if output.status.success() {
            let result = read_output_file(output_file);
            match result {
                Ok(text) => println!("{text}"),
                Err(_) => eprintln!("Could not read output file.")
            }
        } else {
            println!("Program did not execute correctly.");
        }
    } else {
        if output.status.success() {
            eprintln!("Program executed successfully but was expected to return an error");
            io::stdout().flush().unwrap();
            io::stderr().flush().unwrap();
            std::process::exit(1);
        } else {
            // check if output contains "panicked"
            let output_text = String::from_utf8_lossy(&output.stderr);
            if output_text.contains("panicked") {
                eprintln!("Program panicked: you should handle this error gracefully.");
            } else {
                println!("Program exited as expected.");
            }
        }
    }
}

fn read_output_file(file_path: &str) -> io::Result<String> {
    let path = Path::new(file_path);
    if path.exists() {
        let contents = fs::read_to_string(path)?;
        Ok(contents)
    } else {
        Err(io::Error::new(io::ErrorKind::NotFound, "Output file not found"))
    }
}
