#!/usr/bin/env python3
# this example outputsa basic tests.txt
# which has one test - that has no stdin

from cs6991 import test

test.init(__file__, command="MIRI_SYSROOT=$(cat MIRI_SYSROOT) 6991 cargo +nightly miri run --")
print('compile_commands = [\'6991 cargo +nightly miri setup 2>&1 | tail -1 | cut -d\\` -f2 >MIRI_SYSROOT && 6991 cargo build --target-dir target #\']')
print('allow_unexpected_stderr = True')

test.case("", args=[])
test.case("", args=["1"])
test.case("", args=["1", "2"])
test.case("", args=["1", "2", "3"])
test.case("", args=["1", "2", "3", "4", "5"])
