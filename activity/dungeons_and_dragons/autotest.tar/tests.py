#!/usr/bin/env python3
# this example outputsa basic tests.txt
# which has one test - that has no stdin

from cs6991 import test

test.init(__file__)

test.case("d2")
test.case("""d2
d4
""")
test.case("""d2
d4
d6
""")
test.case("""d20
""")
test.case("""d12
""")
test.case("""d2
d4
d6
d8
d10
d12
d20
""")
