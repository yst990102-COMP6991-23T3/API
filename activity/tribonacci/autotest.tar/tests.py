#!/usr/bin/env python3
# this example outputsa basic tests.txt
# which has one test - that has no stdin

from cs6991 import test

test.init(__file__)

test.case("")

test.case("", args=["3"])

test.case("", args=["8"])

test.case("", args=["10"])

test.case("", args=["140"])

test.case("", args=["145"])

test.case("", args=["-100"])

test.case("", args=["hello"])
