#!/usr/bin/env bash

# untar
tar -xvf crate.tar >/dev/null 2>&1

# check if src/test.rs exists
if [ -f src/test.rs ]; then
    echo "Running tests..."
    /usr/local/bin/6991 cargo test
else
    echo "No tests found; Make sure you still have your src/test.rs from the previous activity."
fi


