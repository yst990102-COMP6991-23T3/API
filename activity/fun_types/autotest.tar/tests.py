#!/usr/bin/env python3
# this example outputsa basic tests.txt
# which has one test - that has no stdin

from cs6991 import test

test.init(__file__)

test.case("")
test.case("", args=["1"])
test.case("", args=["2"])
test.case("", args=["1", "2"])
test.case("", args=["3"])
test.case("", args=["1", "2", "3"])
