#!/usr/bin/env python3
# this example outputsa basic tests.txt
# which has one test - that has no stdin

from cs6991 import test

test.init(__file__)

test.case("", args=["hello world!"])

test.case("", args=["🥺👉👈"])


