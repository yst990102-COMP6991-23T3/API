#!/usr/bin/env python3
# this example outputsa basic tests.txt
# which has one test - that has no stdin

from cs6991 import test

test.init(__file__)

test.case("", args=["shreys_art.bmp"])

test.case("", args=["bad_bits_per_pixel.bmp"])

test.case("", args=["bad_compression.bmp"])

test.case("", args=["bad_compression.bmp", "shreys_art.bmp"])

test.case("", args=["bad_compression.bmp", "shreys_art.bmp", "bad_bits_per_pixel.bmp"])

test.case("", args=["bad_compression.bmp", "shreys_art.bmp", "bad_bits_per_pixel.bmp", "fake_filename.bmp"])
