#!/usr/bin/env bash

tar xvf crate.tar 

lines=$(wc -l < questions.md)
if [ $lines -eq 0 ] ; then
    echo "No questions.md file found"
    exit 1
else if [ $lines -gt 18 ]; then
    echo "Looks good!"
    exit 0
else if [ $lines -lt 18 ]; then
    echo "Not enough lines, did you forget to write answers"
    exit 1
fi

