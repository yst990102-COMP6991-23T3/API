#!/usr/bin/env python3
import re
import sys
import subprocess

class colors:
    HEADER = '\033[95m'
    OKBLUE = '\033[94m'
    OKCYAN = '\033[96m'
    OKGREEN = '\033[92m'
    WARNING = '\033[93m'
    FAIL = '\033[91m'
    ENDC = '\033[0m'
    BOLD = '\033[1m'
    UNDERLINE = '\033[4m'

TICK = colors.OKGREEN + "✓" + colors.ENDC
OK = colors.OKCYAN + "~" + colors.ENDC
CROSS = colors.FAIL + "⨯" + colors.ENDC


_print = print
OUTPUT = ""
def print(*args, **kwargs):
    global OUTPUT
    OUTPUT += ' '.join(args) + '\n'
    _print(*args, **kwargs)


def print_test_result(text, result):
    result_text = colors.FAIL + "failed" + colors.ENDC
    if result:
        result_text = colors.OKGREEN + "passed" + colors.ENDC

    print(f"{text} - {result_text}")
    print("="*50)

def print_checklist(text, result):
    if result:
        print(f"[{TICK}] {colors.BOLD}{text}{colors.ENDC}")
    elif result is None:
        print(f"[{OK}] {text}")
    else:
        print(f"[{CROSS}] {colors.BOLD}{text}{colors.ENDC}")

    print("-"*50)

def get_binary_output(bin_path, bin_input=None):
    i = None
    if bin_input:
        i = bin_input.encode('utf-8')
    return subprocess.run(bin_path, input=i, capture_output=True).stdout.decode('utf-8').replace('\n', '\\n').replace('\t', '    ')

def main():
   
    # check that the file has two "#[require_lifetimes(!)]" attributes  
    file = open("src/lib.rs", "r")
    contents = file.read()
    file.close()
    match = re.findall(r'#\[require_lifetimes\(!\)\]', contents)

    if len(match) != 2:  
        print_checklist("Two #[require_lifetimes(!)] attribute's", False)
        return 1
    else:
        print_checklist("Two #[require_lifetimes(!)] attribute's", True)

    # Binary Output
    output = get_binary_output(["/usr/local/bin/6991", "cargo", "test", "--doc"])
    test_names = [
        "identity",
        "split",
    ]

    all_ok = True
    for test in test_names: 

        match = re.search(rf'{test} \(line [0-9]+\) \.\.\. ok', output)
        # check they've entered something, dont care what
        if not match:
            all_ok = False
            print_checklist(test, False)
        else:
            # otherwise they gucci
            print_checklist(test, True) 
    
    match = re.search(rf"0 failed", output)
    if match:
        print_checklist("All doctests passed", True)
    else:
        print_checklist("All doctests passed", False)
        all_ok = False

    if all_ok:
        return 0
    else:
        return 1

if __name__ == "__main__":
    retcode = main()
    sys.exit(retcode)
