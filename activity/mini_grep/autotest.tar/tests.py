#!/usr/bin/env python3

from cs6991 import test

test.init(__file__)

test.case("""\
this line contains the text foo so it is printed
... but this line does not, so it is not printed
""", args=["foo"])

test.case("""\
the pattern can appear inside a larger word: chicken!
""", args=["hi"])

test.case("""\
the pattern is case-insensitive: hi
Hi and hI don't work either
only HI will match this pattern
""", args=["HI"])

test.case("""\
oh and; emojis should work too 😂😂😂
and they follow the same rules: 😃 🌍 🍞 🚗
""", args=["😂"])
