#!/usr/bin/env python3
import io
import os
import re
import pathlib
import sys
import getpass
import subprocess
import zipfile

class colors:
    HEADER = '\033[95m'
    OKBLUE = '\033[94m'
    OKCYAN = '\033[96m'
    OKGREEN = '\033[92m'
    WARNING = '\033[93m'
    FAIL = '\033[91m'
    ENDC = '\033[0m'
    BOLD = '\033[1m'
    UNDERLINE = '\033[4m'

TICK = colors.OKGREEN + "✓" + colors.ENDC
OK = colors.OKCYAN + "~" + colors.ENDC
CROSS = colors.FAIL + "⨯" + colors.ENDC


_print = print
OUTPUT = ""
def print(*args, **kwargs):
    global OUTPUT
    OUTPUT += ' '.join(args) + '\n'
    _print(*args, **kwargs)


def print_test_result(text, result):
    result_text = colors.FAIL + "failed" + colors.ENDC
    if result:
        result_text = colors.OKGREEN + "passed" + colors.ENDC

    print(f"{text} - {result_text}")
    print("="*50)

def print_checklist(text, result):
    if result:
        print(f"[{TICK}] {colors.BOLD}{text}{colors.ENDC}")
    elif result is None:
        print(f"[{OK}] {text}")
    else:
        print(f"[{CROSS}] {colors.BOLD}{text}{colors.ENDC}")

    print("-"*50)

def print_and_has_output(*args, **kwargs):
    try:
        out = subprocess.check_output(*args, stderr=subprocess.STDOUT, universal_newlines=True, **kwargs)
        print(out)
    except subprocess.CalledProcessError as cpe:
        out = False
        print(cpe.output)
    return bool(out)

def get_binary_output(bin_path, bin_input=None):
    i = None
    if bin_input:
        i = bin_input.encode('utf-8')
    return subprocess.check_output(bin_path, input=i).decode('utf-8').replace('\n', '\\n').replace('\t', '    ')

def main():
    reg_submitted = False
    
    # Binary Output
    output = get_binary_output(["/usr/local/bin/6991", "cargo", "test", "--doc"])
    line_map = [
        {"description": "Tests written", "regex": r"running ([0-9]+) test"},
        {"description": "caesar_shift test", "regex": r"caesar_shift \(.*\) \.\.\. ok"},
    ]

    all_ok = True

    for test in line_map: 
        match = re.search(test["regex"], output, re.MULTILINE)
        # check they've entered something, dont care what
        if not match:
            all_ok = False
            print_checklist(test["description"], False)
        else:
            # otherwise they gucci
            print_checklist(test["description"], True) 
        
    if all_ok:
        return 0
    else:
        return 1


if __name__ == "__main__":
    retcode = main()

    sys.exit(retcode)
